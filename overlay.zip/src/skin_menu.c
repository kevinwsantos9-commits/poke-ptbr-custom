#include "global.h"
#include "gflib.h"
#include "clothes.h"
#include "event_object_movement.h"
#include "malloc.h"
#include "menu.h"
#include "option_menu.h"
#include "overworld.h"
#include "sound.h"
#include "task.h"
#include "constants/event_objects.h"
#include "constants/songs.h"

// ---------------------------------------------------------------------------
// Opcoes > SKIN E CORES.
// Cima/Baixo: escolhe a linha | Esq/Dir: muda | A: confirma/liga/desliga | B: voltar
// Linha 0 liga/desliga a skin nova; as linhas 1-6 trocam a cor de cada parte
// (previa em tempo real, de frente, de costas e de lado). Salvo na hora.
// ---------------------------------------------------------------------------

enum { ST_FADEIN, ST_INPUT, ST_FADEOUT };
enum { ROW_SKIN, ROW_PELE, ROW_CABELO, ROW_JAQUETA, ROW_CAMISA, ROW_CALCA, ROW_TENIS, ROW_RESET, ROW_COUNT };

struct SkinMenu
{
    u8 row;
    u8 state;
    u8 spriteIds[3];
};

static EWRAM_DATA struct SkinMenu *sSkinMenu = NULL;

static const u8 sText_Title[]    = _("SKIN E CORES");
static const u8 sText_Help[]     = _("Cima/Baixo  Esq/Dir: mudar  B: voltar");
static const u8 sText_Original[] = _("ORIGINAL (roupas)");
static const u8 sText_New[]      = _("NOVA");
static const u8 sText_Off[]      = _("Ative a skin NOVA");

static const u8 sRowNames[ROW_COUNT][16] = {
    [ROW_SKIN]    = _("SKIN"),
    [ROW_PELE]    = _("PELE"),
    [ROW_CABELO]  = _("CABELO"),
    [ROW_JAQUETA] = _("JAQUETA"),
    [ROW_CAMISA]  = _("CAMISA"),
    [ROW_CALCA]   = _("CALÇA"),
    [ROW_TENIS]   = _("TÊNIS"),
    [ROW_RESET]   = _("RESTAURAR CORES"),
};

enum { WIN_TOP, WIN_LIST, WIN_HELP };

static const struct WindowTemplate sWindowTemplates[] = {
    [WIN_TOP]  = {.bg = 0, .tilemapLeft = 0, .tilemapTop = 0,  .width = 30, .height = 2,  .paletteNum = 15, .baseBlock = 1},
    [WIN_LIST] = {.bg = 0, .tilemapLeft = 0, .tilemapTop = 2,  .width = 22, .height = 16, .paletteNum = 15, .baseBlock = 61},
    [WIN_HELP] = {.bg = 0, .tilemapLeft = 0, .tilemapTop = 18, .width = 30, .height = 2,  .paletteNum = 15, .baseBlock = 421},
    DUMMY_WIN_TEMPLATE
};

static const struct BgTemplate sBgTemplates[] = {
    {
        .bg = 0,
        .charBaseIndex = 0,
        .mapBaseIndex = 31,
        .screenSize = 0,
        .paletteMode = 0,
        .priority = 0,
        .baseTile = 0
    },
};

static const u16 sMenuPalette[16] = {
    RGB(26, 28, 31), RGB(31, 31, 31), RGB(4, 4, 6), RGB(17, 17, 20),
    RGB(26, 4, 4), RGB(31, 20, 20), RGB(3, 18, 5), RGB(20, 28, 20),
    RGB(5, 10, 24), RGB(20, 24, 31), RGB(18, 22, 31), RGB(31, 31, 31),
    RGB(31, 31, 31), RGB(31, 31, 31), RGB(31, 31, 31), RGB(31, 31, 31),
};

static const u8 sColorDark[]  = {TEXT_COLOR_TRANSPARENT, 2, 3};
static const u8 sColorRed[]   = {TEXT_COLOR_TRANSPARENT, 4, 5};
static const u8 sColorGreen[] = {TEXT_COLOR_TRANSPARENT, 6, 7};
static const u8 sColorBlue[]  = {TEXT_COLOR_TRANSPARENT, 8, 3};
static const u8 sColorGray[]  = {TEXT_COLOR_TRANSPARENT, 3, 9};

static void Print(u8 win, const u8 *str, u8 x, u8 y, u8 font, const u8 *colors)
{
    AddTextPrinterParameterized4(win, font, x, y, 0, 0, colors, 0, str);
}

static void Flush(u8 win)
{
    PutWindowTilemap(win);
    CopyWindowToVram(win, COPYWIN_FULL);
}

static void DrawTop(void)
{
    FillWindowPixelBuffer(WIN_TOP, PIXEL_FILL(0));
    Print(WIN_TOP, sText_Title, 4, 0, FONT_NORMAL, sColorBlue);
    Flush(WIN_TOP);
}

static void DrawHelp(void)
{
    FillWindowPixelBuffer(WIN_HELP, PIXEL_FILL(0));
    Print(WIN_HELP, sText_Help, 4, 0, FONT_SMALL, sColorDark);
    Flush(WIN_HELP);
}

static void DrawList(void)
{
    u8 i, y;
    const u8 *colors;
    bool8 on = Skin_IsEnabled();

    FillWindowPixelBuffer(WIN_LIST, PIXEL_FILL(0));
    for (i = 0; i < ROW_COUNT; i++)
    {
        y = i * 16;
        if (i == sSkinMenu->row)
            FillWindowPixelRect(WIN_LIST, PIXEL_FILL(10), 0, y, 176, 16);
        if (i >= ROW_PELE && i <= ROW_TENIS && !on)
            colors = sColorGray;
        else
            colors = (i == sSkinMenu->row) ? sColorRed : sColorDark;
        Print(WIN_LIST, sRowNames[i], 4, y, FONT_NORMAL, colors);
        if (i == ROW_SKIN)
            Print(WIN_LIST, on ? sText_New : sText_Original, 70, y, FONT_NORMAL, on ? sColorGreen : sColorBlue);
        else if (i >= ROW_PELE && i <= ROW_TENIS)
            Print(WIN_LIST, on ? Skin_ColorName(i - ROW_PELE, Skin_GetColor(i - ROW_PELE)) : sText_Off, 70, y, FONT_NORMAL, on ? colors : sColorGray);
    }
    Flush(WIN_LIST);
}

static void RefreshPreview(void)
{
    u8 i;
    u8 equip[CLOTHES_CAT_COUNT];

    Clothes_GetEquipped(equip);
    Clothes_ComposeOutfit(equip);
    Clothes_RefreshPalettes();
    for (i = 0; i < 3; i++)
    {
        if (sSkinMenu->spriteIds[i] != MAX_SPRITES)
            StartSpriteAnim(&gSprites[sSkinMenu->spriteIds[i]], i);
    }
}

static void ChangeValue(s8 delta)
{
    u8 part, n;

    if (sSkinMenu->row == ROW_SKIN)
    {
        Skin_SetEnabled(!Skin_IsEnabled());
    }
    else if (sSkinMenu->row >= ROW_PELE && sSkinMenu->row <= ROW_TENIS)
    {
        if (!Skin_IsEnabled())
        {
            PlaySE(SE_BOO);
            return;
        }
        part = sSkinMenu->row - ROW_PELE;
        n = Skin_NumColors(part);
        Skin_SetColor(part, (Skin_GetColor(part) + n + delta) % n);
    }
    else
    {
        return;
    }
    PlaySE(SE_SELECT);
    RefreshPreview();
    DrawList();
}

static void Exit(void)
{
    Clothes_MarkDirty();
    Clothes_Prepare();
    BeginNormalPaletteFade(PALETTES_ALL, 0, 0, 16, RGB_BLACK);
    sSkinMenu->state = ST_FADEOUT;
}

static void Task_SkinMenu(u8 taskId)
{
    switch (sSkinMenu->state)
    {
    case ST_FADEIN:
        if (!gPaletteFade.active)
            sSkinMenu->state = ST_INPUT;
        break;
    case ST_INPUT:
        if (JOY_NEW(DPAD_UP))
        {
            PlaySE(SE_SELECT);
            sSkinMenu->row = (sSkinMenu->row + ROW_COUNT - 1) % ROW_COUNT;
            DrawList();
        }
        else if (JOY_NEW(DPAD_DOWN))
        {
            PlaySE(SE_SELECT);
            sSkinMenu->row = (sSkinMenu->row + 1) % ROW_COUNT;
            DrawList();
        }
        else if (JOY_NEW(DPAD_LEFT))
            ChangeValue(-1);
        else if (JOY_NEW(DPAD_RIGHT))
            ChangeValue(1);
        else if (JOY_NEW(A_BUTTON))
        {
            if (sSkinMenu->row == ROW_RESET)
            {
                Skin_ResetColors();
                PlaySE(SE_SELECT);
                RefreshPreview();
                DrawList();
            }
            else if (sSkinMenu->row == ROW_SKIN)
                ChangeValue(1);
        }
        else if (JOY_NEW(B_BUTTON) || JOY_NEW(START_BUTTON))
            Exit();
        break;
    case ST_FADEOUT:
        if (!gPaletteFade.active)
        {
            DestroyTask(taskId);
            FreeAllWindowBuffers();
            Free(sSkinMenu);
            sSkinMenu = NULL;
            SetMainCallback2(CB2_OptionsMenuFromStartMenu);
        }
        break;
    }
}

static void CB2_SkinMenu(void)
{
    RunTasks();
    AnimateSprites();
    BuildOamBuffer();
    UpdatePaletteFade();
}

static void VBlankCB_SkinMenu(void)
{
    LoadOam();
    ProcessSpriteCopyRequests();
    TransferPlttBuffer();
}

static void CB2_InitSkinMenu(void)
{
    u8 i;
    static const s16 sPreviewY[3] = {36, 80, 124};

    SetVBlankCallback(NULL);
    DmaClearLarge16(3, (void *)VRAM, VRAM_SIZE, 0x1000);
    DmaClear32(3, (void *)OAM, OAM_SIZE);
    DmaClear16(3, (void *)PLTT, PLTT_SIZE);
    SetGpuReg(REG_OFFSET_DISPCNT, DISPCNT_MODE_0);
    ResetBgsAndClearDma3BusyFlags(0);
    InitBgsFromTemplates(0, sBgTemplates, NELEMS(sBgTemplates));
    InitWindows(sWindowTemplates);
    DeactivateAllTextPrinters();
    ResetSpriteData();
    ResetPaletteFade();
    FreeAllSpritePalettes();
    ResetTasks();
    LoadPalette(sMenuPalette, BG_PLTT_ID(15), sizeof(sMenuPalette));
    LoadPalette(sMenuPalette, BG_PLTT_ID(0), 2);

    for (i = 0; i < 3; i++)
        sSkinMenu->spriteIds[i] = MAX_SPRITES;
    {
        u8 equip[CLOTHES_CAT_COUNT];

        Clothes_GetEquipped(equip);
        Clothes_ComposeOutfit(equip);
    }
    for (i = 0; i < 3; i++)
    {
        sSkinMenu->spriteIds[i] = CreateObjectGraphicsSprite(OBJ_EVENT_GFX_PLAYER_CUSTOM, SpriteCallbackDummy, 208, sPreviewY[i], 0);
        if (sSkinMenu->spriteIds[i] != MAX_SPRITES)
            StartSpriteAnim(&gSprites[sSkinMenu->spriteIds[i]], i);
    }
    Clothes_RefreshPalettes();
    DrawTop();
    DrawList();
    DrawHelp();
    ShowBg(0);
    SetGpuReg(REG_OFFSET_DISPCNT, DISPCNT_MODE_0 | DISPCNT_OBJ_1D_MAP | DISPCNT_OBJ_ON | DISPCNT_BG0_ON);
    BeginNormalPaletteFade(PALETTES_ALL, 0, 16, 0, RGB_BLACK);
    CreateTask(Task_SkinMenu, 0);
    SetVBlankCallback(VBlankCB_SkinMenu);
    SetMainCallback2(CB2_SkinMenu);
}

// Aberto pelo menu de Opcoes (linha "SKIN E CORES"). Volta para as Opcoes.
void CB2_OpenSkinMenu(void)
{
    Clothes_InitIfNeeded();
    sSkinMenu = AllocZeroed(sizeof(struct SkinMenu));
    sSkinMenu->state = ST_FADEIN;
    CB2_InitSkinMenu();
}

gOtherText_NewName::
    .string "NOVO NOME$"

gNameChoice_Green::
    .string "GREEN$"

gNameChoice_Red::
    .string "RED$"

gNameChoice_Leaf::
    .string "LEAF$"

gNameChoice_Fire::
    .string "FIRE$"

gNameChoice_Gary::
    .string "GARY$"

gNameChoice_Kaz::
    .string "KAZ$"

gNameChoice_Toru::
    .string "TORU$"

gNameChoice_Ash::
    .string "ASH$"

gNameChoice_Kene::
    .string "KENE$"

gNameChoice_Geki::
    .string "GEKI$"

gNameChoice_Jak::
    .string "JAK$"

gNameChoice_Janne::
    .string "JANNE$"

gNameChoice_Jonn::
    .string "JONN$"

gNameChoice_Kamon::
    .string "KAMON$"

gNameChoice_Karl::
    .string "KARL$"

gNameChoice_Taylor::
    .string "TAYLOR$"

gNameChoice_Oscar::
    .string "OSCAR$"

gNameChoice_Hiro::
    .string "HIRO$"

gNameChoice_Max::
    .string "MAX$"

gNameChoice_Jon::
    .string "JON$"

gNameChoice_Ralph::
    .string "RALPH$"

gNameChoice_Kay::
    .string "KAY$"

gNameChoice_Tosh::
    .string "TOSH$"

gNameChoice_Roak::
    .string "ROAK$"

gNameChoice_Omi::
    .string "OMI$"

gNameChoice_Jodi::
    .string "JODI$"

gNameChoice_Amanda::
    .string "AMANDA$"

gNameChoice_Hillary::
    .string "HILLARY$"

gNameChoice_Makey::
    .string "MAKEY$"

gNameChoice_Michi::
    .string "MICHI$"

gNameChoice_Paula::
    .string "PAULA$"

gNameChoice_June::
    .string "JUNE$"

gNameChoice_Cassie::
    .string "CASSIE$"

gNameChoice_Rey::
    .string "REY$"

gNameChoice_Seda::
    .string "SEDA$"

gNameChoice_Kiko::
    .string "KIKO$"

gNameChoice_Mina::
    .string "MINA$"

gNameChoice_Norie::
    .string "NORIE$"

gNameChoice_Sai::
    .string "SAI$"

gNameChoice_Momo::
    .string "MOMO$"

gNameChoice_Suzi::
    .string "SUZI$"

gControlsGuide_Text_Intro::
    .string "Os vários botões serão explicados\n"
    .string "por ordem de importância.$"

gControlsGuide_Text_DPad::
    .string "Move o personagem principal.\n"
    .string "Também escolhe os títulos\n"
    .string "dos dados.$"

gControlsGuide_Text_AButton::
    .string "Serve para confirmar, examinar\n"
    .string "coisas, conversar e avançar\n"
    .string "o texto.$"

gControlsGuide_Text_BButton::
    .string "Serve para sair, cancelar uma\n"
    .string "escolha e cancelar um modo.$"

gControlsGuide_Text_StartButton::
    .string "Aperte este botão para abrir o\n"
    .string "MENU.$"

gControlsGuide_Text_SelectButton::
    .string "Troca itens de lugar e usa um\n"
    .string "item registrado.$"

gControlsGuide_Text_LRButtons::
    .string "Se precisar de ajuda para jogar,\n"
    .string "ou saber como fazer as coisas,\n"
    .string "aperte o botão L ou R.$"

gOakSpeech_Text_AskPlayerGender::
    .string "Agora me diga. Você é um menino?\n"
    .string "Ou uma menina?$"

gPikachuIntro_Text_Page1::
    .string "No mundo em que você está prestes\n"
    .string "a entrar, você viverá uma grande\n"
    .string "aventura como o herói da história.\n"
    .string "\n"
    .string "Converse com as pessoas e examine\n"
    .string "tudo por onde passar, seja em\n"
    .string "cidades, estradas ou cavernas.\n"
    .string "Reúna informações e dicas de tudo.$"

gPikachuIntro_Text_Page2::
    .string "Novos caminhos se abrirão ao ajudar\n"
    .string "quem precisa, vencer desafios e\n"
    .string "resolver mistérios.\n"
    .string "\n"
    .string "Às vezes, você será desafiado por\n"
    .string "outros e atacado por criaturas\n"
    .string "selvagens. Seja corajoso e siga em frente.$"

gPikachuIntro_Text_Page3::
    .string "Durante a sua aventura, esperamos\n"
    .string "que você conheça todo tipo de gente\n"
    .string "e cresça como pessoa.\n"
    .string "Esse é o nosso maior objetivo.\n"
    .string "\n"
    .string "Aperte o botão A e que a sua\n"
    .string "aventura comece!$"

gOakSpeech_Text_WelcomeToTheWorld::
    .string "Olá, tudo bem?\n"
    .string "Prazer em conhecer você!\p"
    .string "Bem-vindo ao mundo dos POKéMON!\p"
    .string "Meu nome é OAK.\p"
    .string "As pessoas me chamam carinhosamente\n"
    .string "de PROFESSOR POKéMON.\p$"

gOakSpeech_Text_ThisWorld::
    .string "Este mundo…$"

gOakSpeech_Text_IsInhabitedFarAndWide::
    .string "…é habitado por toda parte por\n"
    .string "criaturas chamadas POKéMON.\p$"

gOakSpeech_Text_IStudyPokemon::
    .string "Para algumas pessoas, os POKéMON\n"
    .string "são bichos de estimação.\n"
    .string "Outras os usam para batalhar.\p"
    .string "Quanto a mim…\p"
    .string "Eu estudo os POKéMON como profissão.\p$"

gOakSpeech_Text_TellMeALittleAboutYourself::
    .string "Mas antes, fale um pouco sobre\n"
    .string "você.\p$"

gOakSpeech_Text_YourNameWhatIsIt::
    .string "Vamos começar pelo seu nome.\n"
    .string "Qual é?\p$"

gOakSpeech_Text_SoYourNameIsPlayer::
    .string "Certo…\n"
    .string "Então o seu nome é {PLAYER}.$"

gOakSpeech_Text_WhatWasHisName::
    .string "Este é o meu neto.\p"
    .string "Ele é o seu rival desde que vocês\n"
    .string "eram bebês.\p"
    .string "…Hum, qual era mesmo o nome dele?$"

gOakSpeech_Text_YourRivalsNameWhatWasIt::
    .string "O nome do seu rival, qual era mesmo?$"

gOakSpeech_Text_ConfirmRivalName::
    .string "…Hum, era {RIVAL}?$"

gOakSpeech_Text_RememberRivalsName::
    .string "Isso mesmo! Agora me lembrei!\n"
    .string "O nome dele é {RIVAL}!\p$"

gOakSpeech_Text_LetsGo::
    .string "{PLAYER}!\p"
    .string "A sua própria lenda POKéMON está\n"
    .string "prestes a começar!\p"
    .string "Um mundo de sonhos e aventuras\n"
    .string "com os POKéMON espera por você!\n"
    .string "Vamos lá!$"

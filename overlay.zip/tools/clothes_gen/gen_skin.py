#!/usr/bin/env python3
"""Converte a folha de sprites enviada (skin_source.png, 7x5 quadros) na 'skin nova'.

Gera:
  graphics/clothes/skin_custom.png       (320x32: 20 quadros 16x32, indices do overworld)
  graphics/clothes/back_skin_custom.png  (64x320: 5 quadros 64x64, indices da batalha)
Os indices sao SEMANTICOS (a paleta real e montada em runtime a partir das cores escolhidas):
  overworld: 1 contorno | 2/3 pele | 4/5 cabelo | 9/10 camisa | 11/12 jaqueta | 13 calca | 8 sombra calca | 15 calcado
  batalha:   1 contorno | 2/3 pele | 4/5 cabelo | 8/9 camisa | 10/11 jaqueta | 12/13 calca | 15 calcado
Uso: python3 tools/clothes_gen/gen_skin.py   (depois o make converte os png em .4bpp)
"""
import os, sys
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, 'skin_source.png')
OUT = os.path.join(HERE, '..', '..', 'graphics', 'clothes')

ROWS = [(19, 231), (263, 482), (507, 728), (755, 971), (998, 1195)]
COLS = [(28, 181), (214, 369), (400, 549), (579, 732), (762, 911), (951, 1094), (1134, 1281)]

# classes
BG, SKIN, SKIN2, HAIR, HAIR2, JAK, JAK2, SHIRT, PANT, PANT2, SHOE, EYE = range(12)

def lum(c): return 0.299 * c[..., 0] + 0.587 * c[..., 1] + 0.114 * c[..., 2]

def load_cell(r, c):
    y0, y1 = ROWS[r]; x0, x1 = COLS[c]
    im = np.array(Image.open(SRC).convert('RGBA'))[y0:y1 + 1, x0:x1 + 1]
    fg = im[..., 3] > 128
    ys, xs = np.where(fg)
    im = im[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    return im[..., :3].astype(float), im[..., 3] > 128

def classify(rgb, fg, view):
    """rotula cada pixel da imagem grande com uma classe semantica"""
    h, w = fg.shape
    R, G, B = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    L = lum(rgb)
    skin = fg & (R > 135) & (G > 85) & (B > 62) & (R > G) & (G >= B - 5) & (R - B > 28)
    red = fg & ~skin & (R > G + 30) & (R > B + 30) & (R > 60) & (G < 85)
    white = fg & ~red & ~skin & (L > 150)
    dark = fg & ~red & ~skin & ~white
    cls = np.zeros((h, w), np.uint8)
    cls[red] = JAK
    cls[red & (L < 38)] = JAK2
    cls[skin] = SKIN
    cls[skin & (L < 175)] = SKIN2
    ys_red = np.where(red.any(axis=1))[0]
    y_jt = ys_red.min() if len(ys_red) else int(h * 0.55)
    y_jb = ys_red.max() if len(ys_red) else int(h * 0.80)
    ys_sk = np.where(skin.any(axis=1))[0]
    xs_sk = np.where(skin.any(axis=0))[0]
    yy = np.arange(h)[:, None] * np.ones((1, w))
    xx = np.ones((h, 1)) * np.arange(w)[None, :]
    # escuros: cabelo (acima da jaqueta), olhos (dentro da area da pele), calca (abaixo da jaqueta)
    hair_zone = dark & (yy < y_jt)
    pant_zone = dark & (yy > y_jb - 0.03 * h)
    mid_zone = dark & ~hair_zone & ~pant_zone
    cls[hair_zone] = HAIR
    cls[mid_zone] = JAK2
    cls[pant_zone] = PANT
    if view != 'N' and len(ys_sk):
        fy0, fy1 = np.percentile(ys_sk, 5), np.percentile(ys_sk, 85)
        fx0, fx1 = xs_sk.min(), xs_sk.max()
        eye = dark & (yy >= fy0) & (yy <= fy1) & (xx >= fx0) & (xx <= fx1) & (yy < y_jt)
        cls[eye & (L < 120)] = EYE
    # branco: camisa (dentro da jaqueta), resto da cabeca = pele, pes = calcado
    cls[white] = SKIN
    cls[white & (yy >= y_jt) & (yy <= y_jb)] = SHIRT
    shoe_y = h * 0.90
    cls[(white | (fg & ~red & ~skin & (L > 85))) & (yy > shoe_y)] = SHOE
    cls[(white) & (yy > y_jb)] = SHOE
    # tons: cabelo/calca claro x escuro
    hl = hair_zone & (L > 52)
    cls[hl] = HAIR2          # HAIR2 = "mais claro" (vira indice principal)
    pl = pant_zone & (L > 32)
    cls[pl] = PANT2
    if view == 'N':
        cls[cls == SHIRT] = JAK
    return cls

def shrink(cls, tw, th, win=1.0):
    """reduz o mapa de classes para tw x th por maioria (com reforco aos detalhes)"""
    h, w = cls.shape
    out = np.zeros((th, tw), np.uint8)
    weight = np.ones(12); weight[EYE] = 1.7; weight[SHIRT] = 1.5; weight[SHOE] = 1.5
    weight[SKIN2] = 1.0; weight[SKIN] = 1.6; weight[SKIN2] = 1.4; weight[EYE] = 2.4
    for ty in range(th):
        for tx in range(tw):
            y0, y1 = int(ty * h / th), max(int((ty + 1) * h / th), int(ty * h / th) + 1)
            x0, x1 = int(tx * w / tw), max(int((tx + 1) * w / tw), int(tx * w / tw) + 1)
            blk = cls[y0:y1, x0:x1]
            cnt = np.bincount(blk.ravel(), minlength=12).astype(float)
            fgfrac = 1 - cnt[BG] / blk.size
            if fgfrac < 0.5:
                continue
            cnt[BG] = 0
            cnt *= weight
            out[ty, tx] = int(np.argmax(cnt))
    return out

# classe -> indice (overworld / batalha)
OW = {SKIN: 2, SKIN2: 3, HAIR: 5, HAIR2: 4, JAK: 11, JAK2: 12, SHIRT: 9, PANT: 8, PANT2: 13, SHOE: 15, EYE: 1}
BK = {SKIN: 2, SKIN2: 3, HAIR: 5, HAIR2: 4, JAK: 10, JAK2: 11, SHIRT: 8, PANT: 13, PANT2: 12, SHOE: 15, EYE: 1}

def place(small, fw, fh, bottom, mapping, dx=0, dy=0):
    th, tw = small.shape
    fr = np.zeros((fh, fw), np.uint8)
    ox = (fw - tw) // 2 + dx
    oy = bottom - th + dy
    for y in range(th):
        for x in range(tw):
            c = small[y, x]
            if c == BG: continue
            X, Y = ox + x, oy + y
            if 0 <= X < fw and 0 <= Y < fh:
                fr[Y, X] = mapping[c]
    return fr

# quadros do overworld (ordem de gen_layers): 0..8 andar (S,N,O parado + passos), 9..17 correr, 18..19 balancar a cabeca
#           (linha, coluna) da folha de origem
SRC_FRAMES = {
    'S': [(1, 2), (1, 3), (1, 6)],
    'N': [(0, 2), (0, 3), (0, 6)],
    'O': [(2, 3), (2, 4), (2, 2)],
}
HEAD = [(1, 0), (1, 1)]

def build_overworld():
    cache = {}
    def get(rc, view):
        if rc not in cache:
            rgb, fg = load_cell(*rc)
            cls = classify(rgb, fg, view)
            cache[rc] = cls
        return cache[rc]
    # tamanho comum: escala fixa por altura media para todos os quadros ficarem consistentes
    TW, TH = 14, 22
    frames = []
    order = [('S', 0), ('N', 0), ('O', 0), ('S', 1), ('S', 2), ('N', 1), ('N', 2), ('O', 1), ('O', 2)]
    def mk(d, st, run):
        rc = SRC_FRAMES[d][st]
        small = shrink(get(rc, d), TW, TH)
        dy = 0
        return place(small, 16, 32, 30 + (1 if st else 0) - (1 if (st and False) else 0), OW, 0, dy)
    for d, st in order: frames.append(mk(d, st, 0))
    for d, st in order: frames.append(mk(d, st, 1))
    for rc in HEAD:
        small = shrink(get(rc, 'S'), TW, TH)
        frames.append(place(small, 16, 32, 30, OW))
    return frames

def build_back():
    rgb, fg = load_cell(0, 2)
    cls = classify(rgb, fg, 'N')
    small = shrink(cls, 40, 52)
    frames = []
    for f in range(5):
        frames.append(place(small, 64, 64, 62, BK, dx=(-2 if f == 0 else 0), dy=0))
    return frames

PAL = [(255, 0, 255), (10, 8, 14), (240, 190, 160), (200, 150, 125), (70, 70, 78), (40, 40, 46),
       (220, 60, 60), (150, 30, 30), (30, 30, 36), (250, 250, 250), (210, 210, 210), (180, 30, 35),
       (110, 15, 20), (30, 30, 34), (200, 160, 40), (150, 150, 160)]

def save(frames, path, vertical):
    fh, fw = frames[0].shape
    n = len(frames)
    img = Image.new('P', (fw, fh * n) if vertical else (fw * n, fh), 0)
    px = img.load()
    for i, fr in enumerate(frames):
        for y in range(fh):
            for x in range(fw):
                px[(x, y + i * fh) if vertical else (x + i * fw, y)] = int(fr[y, x])
    flat = []
    for c in PAL: flat += list(c)
    img.putpalette(flat + [0] * (768 - len(flat)))
    img.save(path)

def preview(frames, path, scale):
    fh, fw = frames[0].shape
    W = Image.new('RGBA', (fw * len(frames), fh), (120, 170, 120, 255))
    for i, fr in enumerate(frames):
        # contorno automatico como no jogo
        f2 = fr.copy()
        for y in range(fh):
            for x in range(fw):
                if f2[y, x] == 0:
                    for dx, dy in ((1,0),(-1,0),(0,1),(0,-1)):
                        X, Y = x+dx, y+dy
                        if 0 <= X < fw and 0 <= Y < fh and fr[Y, X] != 0:
                            f2[y, x] = 1; break
        for y in range(fh):
            for x in range(fw):
                if f2[y, x]:
                    W.putpixel((i * fw + x, y), PAL[f2[y, x]] + (255,))
    W.resize((W.width * scale, W.height * scale), Image.NEAREST).save(path)

if __name__ == '__main__':
    ow = build_overworld(); bk = build_back()
    os.makedirs(OUT, exist_ok=True)
    save(ow, os.path.join(OUT, 'skin_custom.png'), False)
    save(bk, os.path.join(OUT, 'back_skin_custom.png'), True)
    if len(sys.argv) > 1:
        preview(ow, sys.argv[1] + '_ow.png', 4); preview(bk[:1], sys.argv[1] + '_bk.png', 4)
    print('ok')
